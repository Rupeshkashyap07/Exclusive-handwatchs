// DOM Elements
const addToCartButtons = document.querySelectorAll(".add-to-cart");
const cartItemsList = document.getElementById("cart-items");
const totalPriceElement = document.getElementById("total-price");
const emptyCartMessage = document.querySelector(".empty-cart");
const generateBillButton = document.getElementById("generate-bill");
const billSection = document.getElementById("bill");
const billDetails = document.getElementById("bill-details");

let cart = [];
let total = 0;

// Function to update cart UI
function updateCart() {
    cartItemsList.innerHTML = ""; // Clear the list
    if (cart.length === 0) {
        emptyCartMessage.style.display = "block";
        totalPriceElement.textContent = "Total: ₹0";
    } else {
        emptyCartMessage.style.display = "none";
        cart.forEach((item, index) => {
            const li = document.createElement("li");
            li.className = "cart-item";
            li.innerHTML = `
                ${item.name} - ₹${item.price}
                <button class="remove-from-cart" data-index="${index}">Remove</button>
            `;
            cartItemsList.appendChild(li);
        });
        totalPriceElement.textContent = `Total: ₹${total}`;
    }
}

// Add item to cart
addToCartButtons.forEach(button => {
    button.addEventListener("click", function () {
        const productElement = this.parentElement;
        const name = productElement.getAttribute("data-name");
        const price = parseInt(productElement.getAttribute("data-price"));

        // Add to cart and update total
        cart.push({ name, price });
        total += price;

        // Update UI
        updateCart();
    });
});

// Remove item from cart
cartItemsList.addEventListener("click", function (e) {
    if (e.target.classList.contains("remove-from-cart")) {
        const index = e.target.getAttribute("data-index");

        // Update total and remove item
        total -= cart[index].price;
        cart.splice(index, 1);

        // Update UI
        updateCart();
    }
});

// Generate Bill
generateBillButton.addEventListener("click", () => {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Generate bill details
    billDetails.innerHTML = "";
    cart.forEach(item => {
        const billItem = document.createElement("p");
        billItem.textContent = `${item.name} - ₹${item.price}`;
        billDetails.appendChild(billItem);
    });

    const totalBill = document.createElement("p");
    totalBill.style.fontWeight = "bold";
    totalBill.textContent = `Total: ₹${total}`;
    billDetails.appendChild(totalBill);

    // Show bill section
    billSection.style.display = "block";
});

// Initialize UI
updateCart();

