const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Sample user data (normally, you'd fetch this from a database)
const users = [
  { email: 'user@example.com', password: 'password123', mobile: '1234567890' },
  { email: 'admin@example.com', password: 'admin123', mobile: '0987654321' }
];

// Set up body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));

// Set up session middleware
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true
}));

// Serve static files (if needed for images or styles)
app.use(express.static('public'));

// Route for the login page
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/login.html');
});

// Handle login POST request
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Find user by email and check if password matches
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    // If login successful, store user data in session
    req.session.user = { email: user.email, mobile: user.mobile };
    res.redirect('/dashboard');
  } else {
    // If login fails, send an error message
    res.send('Invalid email or password');
  }
});

// Route for the dashboard page
app.get('/dashboard', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }

  // Display user email and mobile number on dashboard
  const { email, mobile } = req.session.user;
  res.send(`
    <h1>Welcome to your Dashboard</h1>
    <p>Email: ${email}</p>
    <p>Mobile Number: ${mobile}</p>
    <a href="/logout">Logout</a>
  `);
});

// Route for logout
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.send('Error logging out');
    }
    res.redirect('/');
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
