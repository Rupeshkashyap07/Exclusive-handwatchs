// Function to show more contact information when the button is clicked
function showContactInfo() {
    var moreInfo = document.getElementById('more-info');
    moreInfo.classList.toggle('hidden');  // Toggle the hidden class to show/hide the extra info
  }
  