<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page </title>
</head>
<form>

    mobile no: <input="text" mobile no.=""><br>
    email: <input="text" email=""><br>
    <input type="submit" name="">
</form>
<body>
    
</body>
</html>