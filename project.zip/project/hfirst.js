// Cart system: Initialize an empty cart
let cartCount = 0;

// Function to handle adding items to the cart
function addToCart(productName, productPrice) {
  cartCount++;
  document.getElementById("cart-count").textContent = cartCount;
  
  // Optional: Log the added product to the console for testing
  console.log(`${productName} has been added to the cart for $${productPrice}`);
}
