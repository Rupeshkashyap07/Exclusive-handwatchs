// Form validation
function validateForm() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;
    var errorMessage = document.getElementById('error-message');
    
    // Clear previous error messages
    errorMessage.innerHTML = "";
    
    // Basic validation
    if (name === "" || email === "" || message === "") {
      errorMessage.innerHTML = "Please fill out all fields.";
      return false;
    }
  
    // Simple email validation regex
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
      errorMessage.innerHTML = "Please enter a valid email address.";
      return false;
    }
  
    // If validation is successful, show a success message (can also be replaced with AJAX for server communication)
    alert("Thank you for reaching out, " + name + "! We will get back to you shortly.");
    return true; // Allow form submission
  }
  